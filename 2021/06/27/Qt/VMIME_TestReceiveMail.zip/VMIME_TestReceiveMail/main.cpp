//#include "mainwindow.h"
//#include <QApplication>

//int main(int argc, char *argv[])
//{
//    QApplication a(argc, argv);

//    MainWindow w;
//    w.show();

//    return a.exec();
//}


#include <QApplication>
#include "listen.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);


    // Set the global C and C++ locale to the user-configured locale.
    // The locale should use UTF-8 encoding for these tests to run successfully.
    try {
        std::locale::global(std::locale(""));
    } catch (std::exception &) {
        std::setlocale(LC_ALL, "");
    }

    listen * ttt= new listen;

    return a.exec();
}
