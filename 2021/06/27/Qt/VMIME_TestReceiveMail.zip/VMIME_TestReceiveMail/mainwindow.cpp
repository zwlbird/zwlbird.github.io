#include "mainwindow.h"
#include "ui_mainwindow.h"


#include <iostream>
#include <locale>
#include <clocale>

#include "vmime/vmime.hpp"
#include "vmime/platforms/posix/posixHandler.hpp"
#include <vmime/net/imap/imap.hpp>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    std::cout << std::endl;

    // Set the global C and C++ locale to the user-configured locale.
    // The locale should use UTF-8 encoding for these tests to run successfully.
    try {
        std::locale::global(std::locale(""));
    } catch (std::exception &) {
        std::setlocale(LC_ALL, "");
    }

    try {

        vmime::messageBuilder mb;
        // Fill in the basic fields
        mb.setExpeditor(vmime::mailbox("me@somewhere.com"));
        vmime::addressList to;
        to.appendAddress(vmime::make_shared <vmime::mailbox>("you@elsewhere.com"));
        mb.setRecipients(to);
        vmime::addressList bcc;
        bcc.appendAddress(vmime::make_shared <vmime::mailbox>("you-bcc@nowhere.com"));
        mb.setBlindCopyRecipients(bcc);
        mb.setSubject(vmime::text("My first message generated with vmime::messageBuilder"));
        // Message body
        mb.getTextPart()->setText(
                    vmime::make_shared <vmime::stringContentHandler>(
                        "I'm writing this short text to test message construction " \
                        "using the vmime::messageBuilder component."
                        )
                    );
        // Construction
        vmime::shared_ptr <vmime::message> msg = mb.construct();
        // Raw text generation
        std::cout << "Generated message:" << std::endl;
        std::cout << "==================" << std::endl;
        vmime::utility::outputStreamAdapter out(std::cout);
        msg->generate(out);


        // VMime exception
    } catch (vmime::exception& e) {

        std::cout << "vmime::exception: " << e.what() << std::endl;
        throw;

        // Standard exception
    } catch (std::exception& e) {

        std::cout << "std::exception: " << e.what() << std::endl;
        throw;
    }

    std::cout << std::endl;
}

MainWindow::~MainWindow()
{
    delete ui;
}
