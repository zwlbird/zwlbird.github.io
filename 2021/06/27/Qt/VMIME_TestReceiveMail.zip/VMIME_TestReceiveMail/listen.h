#ifndef LISTEN_H
#define LISTEN_H

#include <QObject>

#include "vmime/vmime.hpp"


class listen : public QObject
{
    Q_OBJECT
    void connectStore();
    void sendMessage();
public:
    explicit listen(QObject *parent = nullptr);

    vmime::shared_ptr <vmime::net::session> g_session;
    vmime::shared_ptr <vmime::net::store> st;
    vmime::shared_ptr <vmime::net::folder> f;

signals:

public slots:
};

#endif // LISTEN_H
