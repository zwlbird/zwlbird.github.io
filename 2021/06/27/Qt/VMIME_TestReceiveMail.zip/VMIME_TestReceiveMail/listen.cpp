#include "listen.h"

#include <iostream>
#include <sstream>
#include <vector>
#include <map>
#include <locale>
#include <clocale>
#include <QDir>
#include <QFile>

#include <vmime/net/events.hpp>
#include "vmime/platforms/posix/posixHandler.hpp"
#include "vmime/net/imap/imap.hpp"

#include "example/example6_tracer.hpp"
#include "example/example6_authenticator.hpp"
#include "example/example6_certificateVerifier.hpp"
#include "example/example6_timeoutHandler.hpp"

/** Returns the messaging protocols supported by VMime.
  *
  * @param type service type (vmime::net::service::TYPE_STORE or
  * vmime::net::service::TYPE_TRANSPORT)
  */
static const std::string findAvailableProtocols(const vmime::net::service::Type type) {

    vmime::shared_ptr <vmime::net::serviceFactory> sf =
            vmime::net::serviceFactory::getInstance();

    std::ostringstream res;
    size_t count = 0;

    for (size_t i = 0 ; i < sf->getServiceCount() ; ++i) {

        const vmime::net::serviceFactory::registeredService& serv = *sf->getServiceAt(i);

        if (serv.getType() == type) {

            if (count != 0) {
                res << ", ";
            }

            res << serv.getName();
            ++count;
        }
    }

    return res.str();
}


// 定义一个继承自 vmime::net::folder::messageChangedListener 的监听器类
class MymessageCountListener : public vmime::net::events::messageCountListener {

public:
    virtual void messagesAdded(const vmime::shared_ptr <vmime::net::events::messageCountEvent>& event)
    {
        std::cout << "New message added to folder" << std::endl;
    }
    virtual void messagesRemoved(const vmime::shared_ptr <vmime::net::events::messageCountEvent>& event)
    {
        std::cout << "Message flags updated in folder" << std::endl;
    }

};

class MyMessageChangedListener : public vmime::net::events::messageChangedListener {

public:
    void messageChanged(const vmime::shared_ptr<vmime::net::events::messageChangedEvent>& event) {
        std::cout << "Messages expunged from folder " << event.get()->getClass() <<std::endl;
    }
};

class MyFolderListener : public vmime::net::events::folderListener {

public:
    virtual void folderCreated(const vmime::shared_ptr <vmime::net::events::folderEvent>& event)
    {
         std::cout << "folderCreated expunged from folder " << event.get()->getClass() <<std::endl;
    }
    virtual void folderRenamed(const vmime::shared_ptr <vmime::net::events::folderEvent>& event)
    {
         std::cout << "folderRenamed expunged from folder " << event.get()->getClass() <<std::endl;
    }
    virtual void folderDeleted(const vmime::shared_ptr <vmime::net::events::folderEvent>& event)
    {
         std::cout << "folderDeleted expunged from folder " << event.get()->getClass() <<std::endl;
    }
};

// Exception helper
static std::ostream& operator<<(std::ostream& os, const vmime::exception& e) {

    os << "* vmime::exceptions::" << e.name() << std::endl;
    os << "    what = " << e.what() << std::endl;

    // More information for special exceptions
    if (dynamic_cast <const vmime::exceptions::command_error*>(&e)) {

        const vmime::exceptions::command_error& cee =
                dynamic_cast <const vmime::exceptions::command_error&>(e);

        os << "    command = " << cee.command() << std::endl;
        os << "    response = " << cee.response() << std::endl;
    }

    if (dynamic_cast <const vmime::exceptions::invalid_response*>(&e)) {

        const vmime::exceptions::invalid_response& ir =
                dynamic_cast <const vmime::exceptions::invalid_response&>(e);

        os << "    response = " << ir.response() << std::endl;
    }

    if (dynamic_cast <const vmime::exceptions::connection_greeting_error*>(&e)) {

        const vmime::exceptions::connection_greeting_error& cgee =
                dynamic_cast <const vmime::exceptions::connection_greeting_error&>(e);

        os << "    response = " << cgee.response() << std::endl;
    }

    if (dynamic_cast <const vmime::exceptions::authentication_error*>(&e)) {

        const vmime::exceptions::authentication_error& aee =
                dynamic_cast <const vmime::exceptions::authentication_error&>(e);

        os << "    response = " << aee.response() << std::endl;
    }

    if (dynamic_cast <const vmime::exceptions::filesystem_exception*>(&e)) {

        const vmime::exceptions::filesystem_exception& fse =
                dynamic_cast <const vmime::exceptions::filesystem_exception&>(e);

        os << "    path = " << vmime::platform::getHandler()->
              getFileSystemFactory()->pathToString(fse.path()) << std::endl;
    }

    if (e.other()) {
        os << *e.other();
    }

    return os;
}


/** Print the MIME structure of a message on the standard output.
  *
  * @param s structure object
  * @param level current depth
  */
static void printStructure(
        vmime::shared_ptr <const vmime::net::messageStructure> s,
        const int level = 0
        ) {

    for (size_t i = 0 ; i < s->getPartCount() ; ++i) {

        vmime::shared_ptr <const vmime::net::messagePart> part = s->getPartAt(i);

        for (int j = 0 ; j < level * 2 ; ++j) {
            std::cout << " ";
        }

        std::cout
                << (part->getNumber() + 1) << ". "
                << part->getType().generate()
                << " [" << part->getSize() << " byte(s)]"
                << std::endl;

        printStructure(part->getStructure(), level + 1);
    }
}


static const vmime::string getFolderPathString(vmime::shared_ptr <vmime::net::folder> f) {

    const vmime::string n = f->getName().getBuffer();

    if (n.empty()) {  // root folder

        return "/";

    } else {

        vmime::shared_ptr <vmime::net::folder> p = f->getParent();
        return getFolderPathString(p) + n + "/";
    }
}


/** Print folders and sub-folders on the standard output.
  *
  * @param folder current folder
  */
static void printFolders(vmime::shared_ptr <vmime::net::folder> folder, const int level = 0) {

    for (int j = 0 ; j < level * 2 ; ++j) {
        std::cout << " ";
    }

    const vmime::net::folderAttributes attr = folder->getAttributes();
    std::ostringstream attrStr;

    if (attr.getSpecialUse() == vmime::net::folderAttributes::SPECIALUSE_ALL) {
        attrStr << " \\use:All";
    } else if (attr.getSpecialUse() == vmime::net::folderAttributes::SPECIALUSE_ARCHIVE) {
        attrStr << " \\use:Archive";
    } else if (attr.getSpecialUse() == vmime::net::folderAttributes::SPECIALUSE_DRAFTS) {
        attrStr << " \\use:Drafts";
    } else if (attr.getSpecialUse() == vmime::net::folderAttributes::SPECIALUSE_FLAGGED) {
        attrStr << " \\use:Flagged";
    } else if (attr.getSpecialUse() == vmime::net::folderAttributes::SPECIALUSE_JUNK) {
        attrStr << " \\use:Junk";
    } else if (attr.getSpecialUse() == vmime::net::folderAttributes::SPECIALUSE_SENT) {
        attrStr << " \\use:Sent";
    } else if (attr.getSpecialUse() == vmime::net::folderAttributes::SPECIALUSE_TRASH) {
        attrStr << " \\use:Trash";
    } else if (attr.getSpecialUse() == vmime::net::folderAttributes::SPECIALUSE_IMPORTANT) {
        attrStr << " \\use:Important";
    }

    if (attr.getFlags() & vmime::net::folderAttributes::FLAG_HAS_CHILDREN) {
        attrStr << " \\flag:HasChildren";
    }
    if (attr.getFlags() & vmime::net::folderAttributes::FLAG_NO_OPEN) {
        attrStr << " \\flag:NoOpen";
    }

    for (size_t i = 0, n = attr.getUserFlags().size() ; i < n ; ++i) {
        attrStr << " \\" << attr.getUserFlags()[i];
    }

    std::cout << getFolderPathString(folder);
    std::cout << " " << attrStr.str();
    std::cout << std::endl;

    std::vector <vmime::shared_ptr <vmime::net::folder> > subFolders = folder->getFolders(false);

    for (unsigned int i = 0 ; i < subFolders.size() ; ++i) {
        printFolders(subFolders[i], level + 1);
    }
}


/** Print a menu on the standard output.
  *
  * @param choices menu choices
  */
static unsigned int printMenu(const std::vector <std::string>& choices) {

    std::cout << std::endl;

    for (unsigned int i = 0 ; i < choices.size() ; ++i) {
        std::cout << "   " << (i + 1) << ". " << choices[i] << std::endl;
    }

    std::cout << std::endl;
    std::cout << "   Your choice? [1-" << choices.size() << "] ";
    std::cout.flush();

    std::string line;
    std::getline(std::cin, line);

    std::istringstream iss(line);

    unsigned int choice = 0;
    iss >> choice;

    std::cout << std::endl;

    if (choice < 1 || choice > choices.size()) {
        return 0;
    } else {
        return choice;
    }
}


/** Send a message interactively.
  */
void listen::sendMessage() {

    try {

        // Request user to enter an URL
        std::cout << "Enter an URL to connect to transport service." << std::endl;
        std::cout << "Available protocols: " << findAvailableProtocols(vmime::net::service::TYPE_TRANSPORT) << std::endl;
        std::cout << "(eg. smtp://myserver.com, sendmail://localhost)" << std::endl;
        std::cout << "> ";
        std::cout.flush();

        vmime::string urlString;
        std::getline(std::cin, urlString);

        vmime::utility::url url(urlString);

        vmime::shared_ptr <vmime::net::transport> tr;

        if (url.getUsername().empty() || url.getPassword().empty()) {
            tr = g_session->getTransport(url, vmime::make_shared <interactiveAuthenticator>());
        } else {
            tr = g_session->getTransport(url);
        }

#if VMIME_HAVE_TLS_SUPPORT

        // Enable TLS support if available
        tr->setProperty("connection.tls", true);

        // Set the time out handler
        tr->setTimeoutHandlerFactory(vmime::make_shared <timeoutHandlerFactory>());

        // Set the object responsible for verifying certificates, in the
        // case a secured connection is used (TLS/SSL)
        tr->setCertificateVerifier(
                    vmime::make_shared <interactiveCertificateVerifier>()
                    );

#endif // VMIME_HAVE_TLS_SUPPORT

        // You can also set some properties (see example7 to know the properties
        // available for each service). For example, for SMTP:
        if (!url.getUsername().empty() || !url.getPassword().empty()) {
            tr->setProperty("options.need-authentication", true);
        }

        // Trace communication between client and server
        vmime::shared_ptr <std::ostringstream> traceStream = vmime::make_shared <std::ostringstream>();
        tr->setTracerFactory(vmime::make_shared <myTracerFactory>(traceStream));

        // Information about the mail
        std::cout << "Enter email of the expeditor (eg. me@somewhere.com): ";
        std::cout.flush();

        vmime::string fromString;
        std::getline(std::cin, fromString);

        vmime::mailbox from(fromString);
        vmime::mailboxList to;

        for (bool cont = true ; cont ; ) {

            std::cout << "Enter email of the recipient (empty to stop): ";
            std::cout.flush();

            vmime::string toString;
            std::getline(std::cin, toString);

            cont = (toString.size() != 0);

            if (cont) {
                to.appendMailbox(vmime::make_shared <vmime::mailbox>(toString));
            }
        }

        std::cout << "Enter message data, including headers (end with '.' on a single line):" << std::endl;

        std::ostringstream data;

        for (bool cont = true ; cont ; ) {

            std::string line;
            std::getline(std::cin, line);

            if (line == ".") {
                cont = false;
            } else {
                data << line << "\r\n";
            }
        }

        // Connect to server
        tr->connect();

        // Send the message
        vmime::string msgData = data.str();
        vmime::utility::inputStreamStringAdapter vis(msgData);

        tr->send(from, to, vis, msgData.length());

        // Note: you could also write this:
        //     vmime::message msg;
        //     ...
        //     tr->send(&msg);

        // Display connection log
        std::cout << std::endl;
        std::cout << "Connection Trace:" << std::endl;
        std::cout << "=================" << std::endl;
        std::cout << traceStream->str();

        tr->disconnect();

    } catch (vmime::exception& e) {

        std::cerr << std::endl;
        std::cerr << e << std::endl;
        throw;

    } catch (std::exception& e) {

        std::cerr << std::endl;
        std::cerr << "std::exception: " << e.what() << std::endl;
        throw;
    }
}

/** Connect to a message store interactively.
  */
void listen::connectStore() {

    try {

        // Request user to enter an URL
        std::cout << "Enter an URL to connect to store service." << std::endl;
        std::cout << "Available protocols: " << findAvailableProtocols(vmime::net::service::TYPE_STORE) << std::endl;
        std::cout << "(eg. pop3://user:pass@myserver.com, imap://myserver.com:123)" << std::endl;
        std::cout << "> ";
        std::cout.flush();

        // 构建IMAP URL
        std::string mailServer = "imap.163.com"; // 邮件服务器地址
        std::string username = "iscas_test@163.com"; // 你的邮件用户名
        std::string password = "OGCYXJRVVFJUAPTI"; // 你的授权码

        vmime::utility::url url("imap",mailServer, 143,"",username, password);


        // If no authenticator is given in argument to getStore(), a default one
        // is used. Its behaviour is to get the user credentials from the
        // session properties "auth.username" and "auth.password".
//        vmime::shared_ptr <vmime::net::store> st;

        if (url.getUsername().empty() || url.getPassword().empty()) {
            st = g_session->getStore(url, vmime::make_shared <interactiveAuthenticator>());
        } else {
            //            std::cout << url.to_string() << std::endl;
            st = g_session->getStore(url);
        }

//        vmime::shared_ptr <vmime::net::imap::IMAPStore> imapst=std::dynamic_pointer_cast<vmime::net::imap::IMAPStore>(st);

#if VMIME_HAVE_TLS_SUPPORT

        // Enable TLS support if available
        st->setProperty("connection.tls", true);

        // Set the time out handler
        st->setTimeoutHandlerFactory(vmime::make_shared <timeoutHandlerFactory>());

        // Set the object responsible for verifying certificates, in the
        // case a secured connection is used (TLS/SSL)
        st->setCertificateVerifier(
                    vmime::make_shared <interactiveCertificateVerifier>()
                    );

#endif // VMIME_HAVE_TLS_SUPPORT

        // Trace communication between client and server
        vmime::shared_ptr <std::ostringstream> traceStream = vmime::make_shared <std::ostringstream>();
        st->setTracerFactory(vmime::make_shared <myTracerFactory>(traceStream));

        // Connect to the mail store
        st->connect();

        // Display some information about the connection
        vmime::shared_ptr <vmime::net::connectionInfos> ci = st->getConnectionInfos();

        std::cout << std::endl;
        std::cout << "Connected to '" << ci->getHost() << "' (port " << ci->getPort() << ")" << std::endl;
        std::cout << "Connection is " << (st->isSecuredConnection() ? "" : "NOT ") << "secured." << std::endl;

        // Open the default folder in this store
         f = st->getDefaultFolder();
        //		vmime::shared_ptr <vmime::net::folder> f = st->getFolder(vmime::utility::path("a"));

//        vmime::shared_ptr <vmime::net::imap::IMAPFolder> imapf=std::dynamic_pointer_cast<vmime::net::imap::IMAPFolder>(f);
        // 创建消息更改监听器对象
        vmime::shared_ptr<MymessageCountListener> listener = vmime::make_shared<MymessageCountListener>();
        f->addMessageCountListener(new MymessageCountListener);

        vmime::shared_ptr<MyMessageChangedListener> listener1 = vmime::make_shared<MyMessageChangedListener>();
        f->addMessageChangedListener(new MyMessageChangedListener);

        vmime::shared_ptr<MyFolderListener> listener2 = vmime::make_shared<MyFolderListener>();
        f->addFolderListener(new MyFolderListener);

        f->open(vmime::net::folder::MODE_READ_WRITE);

        vmime::size_t count = f->getMessageCount();

        std::cout << std::endl;
        std::cout << count << " message(s) in your inbox" << std::endl;


        std::vector <vmime::shared_ptr <vmime::net::message> > MessageList;
        MessageList=f->getAndFetchMessages(vmime::net::messageSet::byNumber(1,-1),vmime::net::fetchAttributes::FLAGS);
        for (int i=0;i<MessageList.size();i++) {
            vmime::shared_ptr <vmime::net::message> msg = MessageList[i];
            //            if (msg->getFlags() & vmime::net::message::FLAG_RECENT)
            {
                std::cout << "FLAG_RECENT:::" << msg->getFlags()<<","<<msg.get()->getUID() <<std::endl;
            }

            //"Extract whole message"
//            vmime::utility::outputStreamAdapter out(std::cout);
//            msg->extract(out);

            //"Extract attachments"
            vmime::shared_ptr <vmime::message> parsedMsg = msg->getParsedMessage();
            std::vector <vmime::shared_ptr <const vmime::attachment> > attchs =
                    vmime::attachmentHelper::findAttachmentsInMessage(parsedMsg);

            if (attchs.size() > 0) {
                std::cout << attchs.size() << " attachments found." << std::endl;
                for (std::vector <vmime::shared_ptr <const vmime::attachment> >::iterator
                     it = attchs.begin() ; it != attchs.end() ; ++it) {

                    vmime::shared_ptr <const vmime::attachment> att = *it;

                    // Get attachment size
                    vmime::size_t size = 0;

                    if (att->getData()->isEncoded()) {
                        size = att->getData()->getEncoding().getEncoder()->getDecodedSize(att->getData()->getLength());
                    } else {
                        size = att->getData()->getLength();
                    }

                    std::cout << "Found attachment '" << att->getName().getBuffer() << "'"
                              << ", size is " << size << " bytes:" << std::endl;

                    // Get attachment data
                    //                    std::cout << std::endl;
                    //                    std::cout << "========== BEGIN CONTENT ==========" << std::endl;

                    //                    vmime::utility::outputStreamAdapter osa(std::cout);
                    //                    att->getData()->extract(osa);

                    //                    std::cout << std::endl;
                    //                    std::cout << "========== END CONTENT ==========" << std::endl;

                    // Or write it to a file

                    vmime::shared_ptr <vmime::utility::fileSystemFactory> fsf
                            = vmime::platform::getHandler()->getFileSystemFactory();

                    std::string path=QDir::currentPath().toStdString()+"/"+att->getName().getBuffer();
                    vmime::shared_ptr <vmime::utility::file> file
                            = fsf->create(vmime::utility::path(path));

                    QString filepath=QString::fromStdString(path);
                    if(QFile::exists(filepath))
                    {
                        //                    std::cout <<path<< std::endl;
                        QFile::remove(filepath);
                    }

                    file->createFile();
                    vmime::shared_ptr <vmime::utility::outputStream> output =
                            file->getFileWriter()->getOutputStream();

                    att->getData()->extract(*output.get());
                }

            } else {
                std::cout << "No attachments found." << std::endl;
            }

        }

        st->disconnect();

    } catch (vmime::exception& e) {

        std::cerr << std::endl;
        std::cerr << e << std::endl;
        throw;

    } catch (std::exception& e) {

        std::cerr << std::endl;
        std::cerr << "std::exception: " << e.what() << std::endl;
        throw;
    }
}



listen::listen(QObject *parent) : QObject(parent)
{
    g_session = vmime::net::session::create();

    connectStore();
}
