#include "MainWindow.h"
#include "ui_MainWindow.h"

#include "Poco/Net/POP3ClientSession.h"
#include "Poco/Net/MailMessage.h"
#include "Poco/Net/SecureStreamSocket.h"
#include "Poco/Net/Context.h"
#include "Poco/Net/SSLManager.h"
#include "Poco/Net/NetException.h"
#include "Poco/StreamCopier.h"
#include <QFile>
#include <QDebug>
#include <iostream>

using namespace Poco;
using namespace Poco::Net;
using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    string mailServer = "pop.163.com"; // �ʼ���������ַ
    string username = "iscas_test@163.com"; // ����ʼ��û���
    string password = "OGCYXJRVVFJUAPTI"; // �����Ȩ��

    try
    {
        Context::Ptr context = new Context(Context::CLIENT_USE, "", "", "", Context::VERIFY_NONE, 9, false, "ALL:!ADH:!LOW:!EXP:!MD5:@STRENGTH");
        SSLManager::instance().initializeClient(0,0, context);

        SecureStreamSocket socket(context);
        socket.connect(SocketAddress(mailServer, 995));

        POP3ClientSession session(socket);
        session.login(username, password);

        int numMessages = session.messageCount();
        cout << "Total messages: " << numMessages << endl;

        for (int i = 1; i <= numMessages; ++i)
        {
            qDebug()<<"------------------------------------"<<endl;
            MailMessage message;
            session.retrieveMessage(i, message);
            QString sender=QString::fromStdString(message.getSender());
            qDebug() << "From: " << sender << endl;
            qDebug() << "Subject: " << QString::fromStdString(message.getSubject()) << endl;
            //            qDebug() << "Content: " << endl << QString::fromStdString(message.getContent()) << endl;
            // �����ʼ��ĸ�������
            for (const auto& part : message.parts())
            {
                // ��������Ǹ���
                if (part.disposition==MailMessage::CONTENT_ATTACHMENT)
                {
                    // ���������Ϣ
                    cout << "Attachment Name: " << part.pSource->filename() << endl;
                    cout << "Attachment Size: " << part.pSource->getContentLength() << " bytes" << endl;

                    //                               ����������ﱣ�渽���������ļ�
                    //                               QFile file(QString::fromStdString(part.pSource->filename()));
                    //                               file.write(part.pSource->stream());
                    // �򿪱����ļ������
                    FileStream outputFile(part.pSource->filename(), ios::out |ios::binary);
                    // �� PartSource �е� stream ����д�뵽�����ļ���
                    StreamCopier::copyStream(part.pSource->stream(), outputFile);
                }
            }
        }

        session.close();
    }
    catch (Exception& exc)
    {
        cerr << exc.displayText() << endl;
    }

}

MainWindow::~MainWindow()
{
    delete ui;
}
